$(document).ready(function(){
    console.log($('exemplo'))
})