//alert("Olá, seja bem vindo ao curso!");

/*
    selecionar um elememnto do DOM
    atualizar o valor desse elemento com uma string
*/
//document.getElementById('nome').value = 'Oi';

var d = window.document.getElementById('nome').value;
//alert("Olá, "+d+"! Seja bem vindo ao curso!");
console.log(d)