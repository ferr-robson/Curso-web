var altura = 0
var largura = 0
var vidas = 1
var tempo = 10
var criaMosquitoTempo = 1500

var nivel = window.location.search
//nivel.shift()
nivel = nivel.replace('?', '')

if(nivel === 'normal'){
    criaMosquitoTempo = 1500
}else if(nivel === 'dificil'){
    criaMosquitoTempo = 1000
}else if(nivel === 'verry-hard'){
    criaMosquitoTempo = 750
}

function ajustaTamanhoPalcoJogo(){
    altura = window.screen.availHeight
    largura = window.screen.availWidth
    console.log(largura, altura)
}

ajustaTamanhoPalcoJogo()

var cronometro = setInterval(function(){
    tempo -= 1
    if(tempo < 0){
        clearInterval(cronometro)
        clearInterval(criaMosca)
        window.location.href = 'vitoria.html'
    }else{
        document.getElementById('cronometro').innerHTML = tempo
    }
}, 1000)


function posicaoRandomica(){
    if(document.getElementById('mosquito')){         //se ja tem um mosquito na tela, remova-o
        document.getElementById('mosquito').remove()
        if(vidas > 3){
            window.location.href = 'fim_de_jogo.html'
        }else{
            document.getElementById('v' + vidas).src = 'imagens/coracao_vazio.png'
            vidas++
        }
    }

    var posicaoX = Math.floor(Math.random() * largura) - 120 //retiro 120 para nao passa to tamanho da tela
    var posicaoY = Math.floor(Math.random() * altura) - 120

    posicaoX = posicaoX < 0 ? 0 : posicaoX // se x ficar menor que 0 ao subitrair 120, sette ele como 0
    posicaoY = posicaoY < 0 ? 0 : posicaoY // se y ficar menor que 0 ao subitrair 120, sette ele como 0

    //criacao de uma elemento html
    var mosquito = document.createElement('img')
    mosquito.src = 'imagens/mosquito.png'
    mosquito.className = tamanhoAleatorio() + ' ' + ladoAleatorio() //settando a class CSS .mosquitoN e o lado aleatorio
    mosquito.style.left = posicaoX + 'px'   //settando a posicao com base em um X randomico
    mosquito.style.top = posicaoY + 'px'    //settando a posicao com base em um Y randomico
    mosquito.id = 'mosquito'
    mosquito.onclick = function(){ 
        this.remove()    
    }

    document.body.appendChild(mosquito)
}

function tamanhoAleatorio(){
    var classe = Math.floor(Math.random() * 3)
    switch(classe){
        case 0:
            return 'mosquito1' //nao preciso do break devido ao return
        case 1:
            return 'mosquito2' //nao preciso do break devido ao return
        case 2:
            return 'mosquito3' //nao preciso do break devido ao return
    }
}

function ladoAleatorio(){
    var classe = Math.floor(Math.random() * 2)
    switch(classe){
        case 0:
            return 'ladoA'
        case 1:
            return 'ladoB'
    }
}

function timer(){
    var i = 100
    var x = window.setTimeout(function(){
                        i--
                        console.log(i)
                        if(i < 1){
                            clearInterval(x)
                        }
                    }, 100)
}